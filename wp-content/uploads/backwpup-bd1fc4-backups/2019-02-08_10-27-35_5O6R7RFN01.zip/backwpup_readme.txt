Vous avez peut-être remarqué le fichier manifest.json dans cette archive.
manifest.json peut être nécessaire pour une restauration ultérieure de cette sauvegarde.
Veuillez laisser le fichier manifest.json non modifié et à la même place. En d’autres termes, vous pouvez l’ignorer.
